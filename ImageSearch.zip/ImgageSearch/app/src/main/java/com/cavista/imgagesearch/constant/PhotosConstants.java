package com.cavista.imgagesearch.constant;

public class PhotosConstants {
    public static final String IMG_SEARCH_MAIN_PATH="https://api.imgur.com/3/gallery/search/1?q=";
    public static final int COLUMN_COUNT=3;
    public static final int SPACING=30;
    public static final boolean INCLUDE_EDGE=true;
    public static final  String IMG_LOAD_PATH="https://i.imgur.com/";
    public static final String IMG_FORMAT=".jpg";
    public static final String IMG_ID_KEY="img_id";
    public static final String IMG_TITLE_KEY="img_title";
    public static final String KEY="Authorization";
    public static final String CLIENT_ID="Client-ID 137cda6b5008a7c";
    public static final String USER_AGENT="User-Agent";
    public static final String APP="imageSearch";



}
