package com.cavista.imgagesearch.view;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.cavista.imgagesearch.R;
import com.cavista.imgagesearch.constant.PhotosConstants;
import com.cavista.imgagesearch.listeners.ItemClickListener;
import com.cavista.imgagesearch.model.Photos;
import com.squareup.picasso.Picasso;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class GridPhotoAdapter extends RecyclerView.Adapter<GridPhotoAdapter.PhotoViewHolder> {

    private static List<Photos> photos;
    private Context context;
    private ItemClickListener clickListener;

    public GridPhotoAdapter(Context context, List<Photos> photos)
    {
       this.photos=photos;
       this.context=context;
    }

    @NonNull
    @Override
    public PhotoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.item, parent, false);
        return new PhotoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PhotoViewHolder holder, int position) {
        Picasso.with(context).load(PhotosConstants.IMG_LOAD_PATH +
                photos.get(position).getId() + PhotosConstants.IMG_FORMAT).resize(2048,1600).onlyScaleDown().into(holder.photoView);

    }

    public void setClickListener(ItemClickListener itemClickListener) {
        this.clickListener = itemClickListener;
    }

    @Override
    public int getItemCount() {
        return photos.size();
    }

    class PhotoViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener
    {
        ImageView photoView;
//        TextView   title;


        public PhotoViewHolder(@NonNull View itemView) {
            super(itemView);
            photoView=itemView.findViewById(R.id.photo);
//            title= itemView.findViewById(R.id.title);
            photoView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
          if(clickListener!=null)
          {
              clickListener.onClick(v,getAdapterPosition());
          }
        }
    }
    public static  List<Photos> getPhotosList()
    {
        return photos;
    }
}
