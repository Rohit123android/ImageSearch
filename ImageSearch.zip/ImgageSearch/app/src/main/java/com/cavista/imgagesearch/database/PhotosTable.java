package com.cavista.imgagesearch.database;

import android.provider.BaseColumns;

public class PhotosTable implements BaseColumns {
    public static final String TABLE_NAME = "Photos";
    public static final String COLUMN_PHOTO_ID = "photo_id";
    public static final String COLUMN_PHOTO_TITLE = "lastname";
    public static final String COLUMN_PHOTO_COMMENT = "photo_comment";


    public static final String CREATE_TABLE = "CREATE TABLE " +
            TABLE_NAME + " (" +
            COLUMN_PHOTO_ID + " TEXT, " +
            COLUMN_PHOTO_TITLE + " TEXT, " + COLUMN_PHOTO_COMMENT + " TEXT" + ")";

}