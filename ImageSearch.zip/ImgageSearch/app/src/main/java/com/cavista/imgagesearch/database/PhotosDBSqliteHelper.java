package com.cavista.imgagesearch.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

/**
 * photo database
 */

public class PhotosDBSqliteHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "photos_database";
    private static PhotosDBSqliteHelper mInstance = null;


    private  PhotosDBSqliteHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }



    public static PhotosDBSqliteHelper getInstance(Context ctx) {
        /**
         * use the application context as suggested by CommonsWare.
         * this will ensure that you dont accidentally leak an Activitys
         * context (see this article for more information:
         * http://android-developers.blogspot.nl/2009/01/avoiding-memory-leaks.html)
         */
        if (mInstance == null) {
            mInstance = new PhotosDBSqliteHelper(ctx.getApplicationContext());
        }
        return mInstance;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(PhotosTable.CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + PhotosTable.TABLE_NAME);
        onCreate(db);
    }

    /**
     * insert photo data
     * @param photo_id
     * @param photo_title
     * @param photo_comment
     * @return
     */

    public  boolean insertData(String photo_id,String photo_title,String photo_comment)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put(PhotosTable.COLUMN_PHOTO_ID,photo_id);
        cv.put(PhotosTable.COLUMN_PHOTO_TITLE,photo_title);
        cv.put(PhotosTable.COLUMN_PHOTO_COMMENT,photo_comment);

        long result= db.insert(PhotosTable.TABLE_NAME,null,cv);
        if(result==-1)
            return false;
        else
            return true;

    }

    /**
     * update photo data
     * @param photo_id
     * @param photo_title
     * @param photo_comment
     * @return
     */
    public boolean updateData(String photo_id,String photo_title,String photo_comment)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put(PhotosTable.COLUMN_PHOTO_ID,photo_id);
        cv.put(PhotosTable.COLUMN_PHOTO_TITLE,photo_title);
        cv.put(PhotosTable.COLUMN_PHOTO_COMMENT,photo_comment);
        db.update(PhotosTable.TABLE_NAME,cv,  PhotosTable.COLUMN_PHOTO_ID  +"= ?",new String[]{photo_id});
        return  true;
    }

    /**
     * check whether data exist
     * @param photoID
     * @return
     */
    public   boolean checkIfExist(String photoID) {

        String checkString = "Select * From " + PhotosTable.TABLE_NAME + " where  " + PhotosTable.COLUMN_PHOTO_ID  + "='" + photoID + "'";
        return (getWritableDatabase().rawQuery(checkString,null).getCount()>0);
    }

    /**
     * fetch data
     * @param photoID
     * @return
     */
    public  String getComment(String photoID) {

        String queryString = "Select * From " + PhotosTable.TABLE_NAME + " where  " + PhotosTable.COLUMN_PHOTO_ID  + "='" + photoID + "'";

        SQLiteDatabase db  = this.getReadableDatabase();
        Cursor cursor      = db.rawQuery(queryString, null);
        String comment=null;

        if (cursor.moveToFirst()) {

                // get the data into array, or class variable
                comment=cursor.getString( cursor.getColumnIndex(PhotosTable.COLUMN_PHOTO_COMMENT) );

        }
        cursor.close();
        return comment;
    }

}
