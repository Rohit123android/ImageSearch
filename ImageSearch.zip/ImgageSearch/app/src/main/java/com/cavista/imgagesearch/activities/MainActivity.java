package com.cavista.imgagesearch.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.cavista.imgagesearch.R;
import com.cavista.imgagesearch.constant.PhotosConstants;
import com.cavista.imgagesearch.listeners.ItemClickListener;
import com.cavista.imgagesearch.model.Photos;
import com.cavista.imgagesearch.view.GridPhotoAdapter;
import com.cavista.imgagesearch.view.GridSpacingItemDecoration;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
/**
 * this case all the image search activities and displaying searched image list
 */

import static android.content.ContentValues.TAG;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, ItemClickListener {
    private OkHttpClient httpClient;
    private ImageView searchPhotosButton;
    private EditText searchPhotosEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        initViews();
    }

    /**
     * initialize  all views
     */
    void initViews()
    {
        searchPhotosButton=findViewById(R.id.search_button);
        searchPhotosButton.setOnClickListener(this);
        searchPhotosEditText=findViewById(R.id.search_edit);

    }

    /**
     * fetch image based on search bar string
     * @param searchString search bar string
     */
    private void fetchData(String searchString) {
        httpClient = new OkHttpClient.Builder().build();
        Request request = new Request.Builder()
                .url(PhotosConstants.IMG_SEARCH_MAIN_PATH + searchString +"")
                .header(PhotosConstants.KEY,PhotosConstants.CLIENT_ID)
                .header(PhotosConstants.USER_AGENT,PhotosConstants.APP)
                .build();

        httpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "An error has occurred " + e);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                // More code goes here

                JSONObject data = null;
                JSONArray items = null;
                try {
                    data = new JSONObject(response.body().string());
                    items= data.getJSONArray("data");
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                final List<Photos> photos = new ArrayList<Photos>();

                for(int i=0; i<items.length();i++) {
                    JSONObject item = null;
                    try {
                        item = items.getJSONObject(i);
                        Photos photo = new Photos();
                        if(item.getBoolean("is_album")) {
                            photo.setId(item.getString("cover"));
                        } else {
                            photo.setId(item.getString("id")); ;
                        }
                        photo.setTitle(item.getString("title"));

                        photos.add(photo); // Add photo to list
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        render(photos);
                    }
                });
            }
        });


    }

    /**
     * render search images into recyeclerview
     * @param photos photos list
     */
    private void render(final List<Photos> photos) {
        RecyclerView rv = (RecyclerView)findViewById(R.id.photo_gallary);
       rv.setLayoutManager(new GridLayoutManager(this,PhotosConstants.COLUMN_COUNT));
        GridPhotoAdapter photosAdapter =new GridPhotoAdapter(this,photos);
        photosAdapter.setClickListener(this);
        rv.setAdapter(photosAdapter);
        rv.addItemDecoration(new GridSpacingItemDecoration(PhotosConstants.COLUMN_COUNT, PhotosConstants.SPACING, PhotosConstants.INCLUDE_EDGE));

    }

    //on click event
    @Override
    public void onClick(View v) {
        switch(v.getId())
        {
            case R.id.search_button:

                String searchString=searchPhotosEditText.getText().toString().trim();
                if(searchString.isEmpty() || searchString.length() == 0 || searchString.equals("") || searchString == null)
                {
                    Toast.makeText(MainActivity.this,"string is empty",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    fetchData(searchString);
                }


        }
    }

    /**
     * recyelerview item click
     * @param view grid image
     * @param position image position
     */

    @Override
    public void onClick(View view, int position) {
        List<Photos> photos =GridPhotoAdapter.getPhotosList();
        final Photos photo =photos.get(position);
        String imgID=photo.getId();
        String  title=photo.getTitle();
        Intent intent =new Intent(this,ImageActivity.class);
        intent.putExtra(PhotosConstants.IMG_ID_KEY,imgID);
        intent.putExtra(PhotosConstants.IMG_TITLE_KEY,title);
        startActivity(intent);

    }
}
