package com.cavista.imgagesearch.activities

import android.graphics.Color
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.cavista.imgagesearch.R
import com.cavista.imgagesearch.constant.PhotosConstants
import com.cavista.imgagesearch.database.PhotosDBSqliteHelper
import com.squareup.picasso.Picasso

/**
 * activity for the image detail and comment on the image.
 */
class ImageActivity : AppCompatActivity(),View.OnClickListener {
    lateinit var photoPreview:ImageView
    lateinit var titleText:TextView
    lateinit var back_press:ImageView
    lateinit var comment_edit:EditText
    lateinit var  submit_button:Button
    var height:Int=0
    var width:Int=0
    lateinit var  imgID:String
    lateinit var  imgTitle:String
    lateinit var photo_path:String
    lateinit var database:PhotosDBSqliteHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_image)
        initViews()
         imgID=intent.getStringExtra(PhotosConstants.IMG_ID_KEY)
         imgTitle =intent.getStringExtra(PhotosConstants.IMG_TITLE_KEY)

        photo_path=PhotosConstants.IMG_LOAD_PATH + imgID + PhotosConstants.IMG_FORMAT

        //load image in using picasso

        Picasso.with(this).load(PhotosConstants.IMG_LOAD_PATH +
               imgID+ PhotosConstants.IMG_FORMAT).resize(width, width).onlyScaleDown().into(photoPreview)
             titleText.text=imgTitle

        database=PhotosDBSqliteHelper.getInstance(this@ImageActivity)

        //set  image comment from local database if exist

       if(database.checkIfExist(photo_path))
       {
           comment_edit.setText(database.getComment(photo_path))
       }
    }

    /**
     * initialize all views
     */

    fun initViews()
    {
        photoPreview =findViewById(R.id.image_preview)
        titleText =findViewById(R.id.image_title_txt)
        back_press =findViewById(R.id.back_button)
        back_press.setColorFilter(Color.WHITE)
        comment_edit =findViewById(R.id.comment_edit_txt)
        submit_button =findViewById(R.id.submit_button)
        back_press.setOnClickListener(this)
        submit_button.setOnClickListener(this)
        getDeviceWidthAndHeight()
//set imageview layout params
        photoPreview.layoutParams.width=width
        photoPreview.layoutParams.height=width
        photoPreview.requestLayout()

    }

    /**
     * button on click function
     */
    override fun onClick(v: View?) {
     when(v?.id)
     {
         R.id.back_button -> {
             super.onBackPressed()
         }
           R.id.submit_button ->{
               var commentString=comment_edit?.text.toString().trim()
               if (commentString.isNotBlank() || commentString.isNotBlank()) {

                // if comment exist for the image then update comment otherwise insert comment
                   if (database.checkIfExist(photo_path))
                   {
                     database.updateData(photo_path,imgTitle,commentString)
                   }
                   else
                   {
                       database.insertData(photo_path,imgTitle,commentString)
                   }
               }

              else {
                   Toast.makeText(this , "string is empty", Toast.LENGTH_SHORT).show()
             }

         }

         else ->
         {

         }
     }
    }

    /**
     * get device width and height
     */
    fun getDeviceWidthAndHeight()
    {
        val displayMetrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(displayMetrics)
        height= displayMetrics.heightPixels
         width = displayMetrics.widthPixels
    }
}
